set -Eeuo pipefail
repo=/home/tuyenkv/projects/sat-bound-search-v45-long-r2
root="$repo/results/aglr/sat-bound-search-v45-long600-20261120"
cd "$repo"
exec 9>"$root/followup-control.lock"
flock -n 9
trap 'printf "exit=%s line=%s\n" "$?" "$LINENO" > "$root/FOLLOWUP_FAILED"' ERR
source /home/tuyenkv/.cargo/env
source /home/tuyenkv/miniconda3/etc/profile.d/conda.sh
conda activate gurobi
export GUROBI_HOME=/home/tuyenkv/miniconda3/envs/gurobi LD_LIBRARY_PATH=/home/tuyenkv/miniconda3/envs/gurobi/lib GRB_LICENSE_FILE=/home/tuyenkv/gurobi.lic
reference=/home/tuyenkv/projects/core-exhaust-v17-followup/maxsattrainscheduling/results/aglr/core-exhaust-v17-full216
diagnostics=/home/tuyenkv/projects/bound-diagnostics-v39/results/aglr/bound-diagnostics-v39-20261109
mip=/home/tuyenkv/projects/maxsattrainscheduling/results/aglr/full-final-120-20261108/BigM-Gurobi
cplex=/home/tuyenkv/projects/cplex-tail-v45-retry/results/aglr/cplex-reference300-v45-20261120
python3 quick_scripts/analyze/run_sat_bound_search.py run --reference "$reference" --diagnostic-root "$diagnostics" \
  --binary "$root/solver/sat_bound_search" --build-manifest "$root/build_manifest.json" \
  --threshold-policy upper --rc2-warmup-seconds 60 --threshold-session reuse --timeout 600 --round-seconds 21000 \
  --selection-archive results/sat_research/v42_sat_bound_search_20261109/complete_snapshot.tar.gz \
  --followup "$root/hard" --results "$root/followup"
if test -f "$root/followup/followup_stopped.json"; then touch "$root/FOLLOWUP_NOT_REPRODUCED"; exit 0; fi
if ! python3 -c 'import json,sys; sys.exit(not json.load(open(sys.argv[1]))["complete"])' "$root/followup/audit.json"; then
  touch "$root/FOLLOWUP_INCOMPLETE"; exit 0
fi
python3 quick_scripts/analyze/compare_search_bounds.py --candidate "$root/hard" --followup "$root/followup" \
  --reference "$reference" --diagnostics "$diagnostics" --cplex-tail "$cplex" \
  --gurobi-json cont "$mip/cont.json" --gurobi-json infsteps180 "$mip/infsteps180.json" \
  --reference-pool "$root/full-reference-pool.json" --output "$root/full-evaluation.json"
touch "$root/FOLLOWUP_COMPLETED"
