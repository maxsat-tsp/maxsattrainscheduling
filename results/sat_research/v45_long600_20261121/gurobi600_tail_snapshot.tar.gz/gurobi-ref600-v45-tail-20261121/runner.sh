#!/usr/bin/env bash
set -Eeuo pipefail
base=/home/tuyenkv/projects/sat-bound-search-v45-long-r2/results/aglr/sat-bound-search-v45-long600-20261120
repo=/home/tuyenkv/projects/sat-bound-search-v45-controls-recovery
root="$repo/results/aglr/gurobi-ref600-v45-tail-20261121"
mkdir -p "$root"
exec 9>"$root/campaign.lock"
flock -n 9
[[ ! -e "$root/COMPLETED" && ! -e "$root/FAILED" ]] || exit 0
trap 'printf "exit=%s line=%s\n" "$?" "$LINENO" > "$root/FAILED"; exit 78' ERR
source /home/tuyenkv/miniconda3/etc/profile.d/conda.sh
conda activate gurobi
export GUROBI_HOME=/home/tuyenkv/miniconda3/envs/gurobi
export LD_LIBRARY_PATH="$GUROBI_HOME/lib"
export GRB_LICENSE_FILE=/home/tuyenkv/gurobi.lic
cd "$repo"
cp "$0" "$root/runner.sh"
PYTHONPATH=quick_scripts/analyze python3 - "$base" "$root" <<'PY'
import json,os,subprocess,sys
from pathlib import Path
from types import SimpleNamespace
import extended_timeout_experiments as ex
from run_long_baseline_cases import CUTOFF, case_evidence, checked_case

base,root=map(Path,sys.argv[1:])
assert (base/'FOLLOWUP_COMPLETED').is_file()
m=json.loads((base/'controls/BigM-Gurobi/manifest.json').read_text())
binary=base/'solver/ddd'
assert ex.focus.sha(binary)==m['binary_sha256']
assert m['dataset_sha256']==ex.focus.dataset_hash()
o,n='infsteps180','stationA8'
old_file=Path('results/sat_research/baseline_inventory_20261110/final_independent_audit.json')
old=json.loads(old_file.read_text())['inventory']
long_audit=base/'controls/BigM-Gurobi/audit.json'
long=json.loads(long_audit.read_text())
assert long['complete'] and long['audit_passed'] and long['timeout_seconds']==CUTOFF==600
covered={(r['objective'],r['name']) for r in long['cases']}
assert set(map(tuple,old['observed_no_proof_at_cutoff']))-covered=={(o,n)}
reference=base/'full-evaluation.json'
report=json.loads(reference.read_text())
assert report['candidate_audit_passed'] and report['full_comparison']['complete']
known=next(r for r in report['cases'] if (r['objective'],r['name'])==(o,n))
assert known['proven']
case=root/'case'
assert not case.exists()
lock=dict(method='BigM-Gurobi',binary_source_commit=m['runner_commit'],
    runner_commit=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),
    binary_sha256=m['binary_sha256'],dataset_sha256=m['dataset_sha256'],timeout_seconds=CUTOFF,
    ram_kb=m['ram_kb'],threads_milp=m['threads_milp'],cpu_affinity=sorted(os.sched_getaffinity(0)),
    objective=o,name=n,source_sha256={str(p):ex.focus.sha(p) for p in [old_file,long_audit,reference]},
    audit_only_reference=True)
ex.save(root/'manifest.json',lock)
ex.run_case('BigM-Gurobi',o,n,SimpleNamespace(timeout=CUTOFF,ram_kb=m['ram_kb'],binary=binary),case)
ex.save(case/'completion.json',case_evidence(case,'BigM-Gurobi',o,n,lock))
ex.save(root/'audit.json',checked_case(case,'BigM-Gurobi',o,n,lock,known))
PY
touch "$root/COMPLETED"
